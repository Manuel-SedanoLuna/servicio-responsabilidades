import os
import types
import calendar

import numpy as np
import pandas as pd
from .http_controller import HTTPController

connection = HTTPController()

# def EDA(id_tienda: int,):